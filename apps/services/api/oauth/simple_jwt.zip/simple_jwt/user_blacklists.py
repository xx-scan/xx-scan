# coding:utf-8

from rest_framework import serializers, viewsets, routers
# from rest_framework.response import Response
from rest_framework import permissions
from rest_framework_simplejwt.token_blacklist.models import (BlacklistedToken,
                                                             OutstandingToken, )
from .permissions import OnlyGetAndSupderAdminPermission

class BlacklistedTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = BlacklistedToken
        fields = ("blacklisted_at", "token_id")


class OutstandingTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = OutstandingToken
        fields = ("token", "created_at", "expires_at", "user_id", "jti")


class OutstandingTokenView(viewsets.ModelViewSet):
    queryset = OutstandingToken.objects.all()
    serializer_class = OutstandingTokenSerializer
    permission_classes = (OnlyGetAndSupderAdminPermission,)


class BlacklistedTokenView(viewsets.ModelViewSet):
    queryset = BlacklistedToken.objects.all()
    serializer_class = BlacklistedTokenSerializer
    permission_classes = (OnlyGetAndSupderAdminPermission,)

bl_router = routers.DefaultRouter()
bl_router.register(r'outs_tokens', OutstandingTokenView)      ### 未完成的Token视图
bl_router.register(r'blist_tokens', BlacklistedTokenView)      ### 黑名单的列表

## /waf/mg/bl_token/blist_tokens/
## /waf/mg/bl_token/outs_tokens/