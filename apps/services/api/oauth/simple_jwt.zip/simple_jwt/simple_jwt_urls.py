from .simple_jwt_views import MyTokenObtainPairView
from django.conf.urls import url, include


from rest_framework_simplejwt.views import (
    TokenObtainSlidingView,
    TokenRefreshSlidingView,
    TokenVerifyView,
)

urlpatterns = [
    ## 登陆和刷新令牌; 滑动令牌
    url(r'^api/simple_jwt/token/$', TokenObtainSlidingView.as_view(), name='token_obtain'),
    url(r'^api/simple_jwt/refresh/$', TokenRefreshSlidingView.as_view(), name='token_refresh'),

    ## 是否有效
    url(r'^api/simple_jwt_token/verify/$', TokenVerifyView.as_view(), name='token_verify'),
]

from .user_blacklists import bl_router
urlpatterns.append(url(r'^bl_token/', include(bl_router.urls)))