# coding:utf-8
from datetime import datetime, timedelta

from django.core.cache import cache
from .settings import USER_CACHE, UserManageParams

class UserCache():

    def __init__(self, user=None, remote_addr=None):
        self.user = user
        self.remote_addr = remote_addr
        self.username = remote_addr  ## 紧急修复, 本工具中的 Username 就是 IP
        # self._cache_keys = set()
        self.cache_keys = [self.username + k for k in USER_CACHE.keys()]
        self.cache_keys.extend(["_last_logined"] )
        # self.cache = cache
        self.user_manage = UserManageParams()

    def get_all_keys_sets(self):
        temp = {}
        for key in self.cache_keys:
            temp.setdefault(key, cache.get(key))
        return dict(username=self.user.username, cache_data=temp)

    def _cache_keys(self):
        return

    def inital(self):
        ## 登陆过程中的缓存过滤器
        cache.set(self.username + USER_CACHE["user_info_suffix"], self.user or self.username)  ## 用户信息存储
        # cache.set(self.username + USER_CACHE["user_token_suffix"], self.user.token)  ## 用户有效token
        pass

    def delete(self):
        for key in self.cache_keys:
            cache.delete(self.user.username + key)
        return True

    def variate_login_history(self):
        ## 鉴别历史时间是否是有效的 ; 只保留 1 min 内的 5 个时间
        _cache_key = self.username + USER_CACHE["user_login_faild_dtlist"]
        now_timestamp = datetime.now()
        login_list = cache.get(_cache_key)
        _login_failed_dt_list = [x for x in login_list if x < now_timestamp - timedelta(seconds=self.user_manage.caculate_period)]
        cache.set(_cache_key, _login_failed_dt_list)
        if (len(_login_failed_dt_list) >= self.user_manage.user_login_times_len):
            return False
        return True

    def failed_cache_init(self):
        self.inital()

        login_failed_dt_hostory_key = self.username + USER_CACHE["user_login_faild_dtlist"]
        if cache.get(login_failed_dt_hostory_key):
            new_list = cache.get(login_failed_dt_hostory_key)
            new_list.extend([datetime.now()])
            cache.set(login_failed_dt_hostory_key, new_list)
        else:
            ## 首次登陆失败, 并没有产生登陆失败的历史
            cache.set(login_failed_dt_hostory_key, [])

        if not self.variate_login_history():
            _banned_seconds = UserManageParams().banned_long
            cache.set( self.username + USER_CACHE["user_stat_suffix"], False, _banned_seconds)  ## 用户有效token
            cache.set( self.username + USER_CACHE["user_expire_bd_time"], datetime.now() + timedelta(seconds=_banned_seconds) )
            return {"stat": -1} ## 开始封禁

        return {"stat": 1} ## 登陆失败, 但是仍然有机会

    ## 登陆成功的验证;
    def seccuss_cache_init(self):
        self.inital()
        login_stat = cache.get(self.username + USER_CACHE["user_stat_suffix"])
        if login_stat:
            if login_stat == False:
                return {"stat": -1} ## 封禁时间内
        cache.set(self.username + USER_CACHE["user_stat_suffix"], True) ## 正常状态 // 封禁结束或者初次登陆
        #cache.set(self.username + "_last_logined", datetime.now()) ## 记录IP最近登陆时间
        ## 只有失败才会产生的键
        if cache.get(self.username + USER_CACHE["user_login_faild_dtlist"]):
            cache.delete(self.username + USER_CACHE["user_login_faild_dtlist"])
        if cache.get(self.username + USER_CACHE["user_expire_bd_time"]):
            cache.delete(self.username + USER_CACHE["user_expire_bd_time"])
        return {"stat": 0} ## 允许正常登陆
