# coding:utf-8


USER_CACHE = dict(
    user_info_suffix="", ## 用户信息
    user_stat_suffix="_stat",  ## 用户登陆状态的后缀名
    user_token_suffix="_token",     ## 用户有效的TOKEN记录
    user_login_faild_dtlist="_history",  ## 用户登陆的历史记录
    user_expire_bd_time= "_expire_bd",   ## 用户解封时间
    user_last_logined= "",   ## 用户解封时间
)


class UserManageParams():
    def __init__(self):
        self.user_login_times_len = 5
        self.caculate_period = 60
        self.banned_long = 60*5

